create definer = root@`%` trigger compute
    after insert
    on orderNote
    for each row
BEGIN
	update `order` SET order_amount = order_amount + new.goods_amount WHERE `order`.order_id = new.order_id;
	END;

