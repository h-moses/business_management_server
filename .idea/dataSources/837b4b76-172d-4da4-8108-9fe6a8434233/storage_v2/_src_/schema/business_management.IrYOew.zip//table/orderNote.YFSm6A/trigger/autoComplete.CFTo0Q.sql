create definer = root@`%` trigger autoComplete
    before insert
    on orderNote
    for each row
BEGIN
	set new.goods_name = (SELECT goods_name FROM goods WHERE goods_id = new.goods_id);
	set new.goods_avatar = (SELECT goods_avatar FROM goods WHERE goods_id = new.goods_id);
	set new.unit_price = (SELECT unit_price FROM goods WHERE goods_id = new.goods_id);
	set new.goods_amount = new.unit_price * new.goods_quantity;
END;

