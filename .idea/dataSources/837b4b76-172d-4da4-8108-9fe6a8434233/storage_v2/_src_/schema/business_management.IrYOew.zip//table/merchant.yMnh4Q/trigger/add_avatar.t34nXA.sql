create definer = root@`%` trigger add_avatar
    before insert
    on merchant
    for each row
BEGIN
	SET new.mc_avatar = 'https://cdn.vuetifyjs.com/images/logos/vuetify-logo-dark.png';
END;

